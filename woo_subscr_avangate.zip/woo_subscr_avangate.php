<?php
/**
 * Plugin Name: Woo Avangate Gateway
 * Plugin URI: https://github.com/Themoholics/woo_subscr_avangate
 * Description: Adding Avangate functionality to WooCommerce 
 * Version: 1.0
 * Author: kaiser
 * Author URI: http://dzen.yandex.com
 * License: GPL2
 */
if (!class_exists('WooAvangateExpansion'))
{

	class WooAvangateExpansion
	{

		const CLASS_DIR_PATH = 'classes';

		const NAME = 'subscription';

		public $version = '1.0';
		public $plugin_url;
		public $plugin_path;
		public $class_path;

		public function __construct()
		{
			$this->init();
			$this->registerAutoloader();

			if (!$this->isWooInastlled())
			{
				$this->woocommerceInactiveNotice();
				return;
			}

			add_action('plugins_loaded', array($this, 'initAvangateGateway'));
			add_filter('woocommerce_payment_gateways', array($this, 'addAvangateGateway'));

			if (is_admin())
			{
				$admin = new Admin();
				$admin->init();
			}
		}

		private function init()
		{
			$this->setPluginPath();
			$this->setPluginUrl();
			$this->setClassPath();
		}

//
//		/**
//		 * Adding WooComerce->Subscription
//		 */
//		private function addSubscriptionSubPage()
//		{
//
//		}
//
//		/**
//		 * Adding to product tab with avangate product id
//		 * @see http://www.benblanco.com/how-to-add-custom-product-tab-to-woocommerce-single-product-page/
//		 */
//		private function addProductIdMeta()
//		{
//
//		}

		/*
		 * Plugin House Keeping
		 */

		/**
		 * Called when WooCommerce is inactive to display an inactive notice.
		 *
		 * @since 1.2
		 */
		private function woocommerceInactiveNotice()
		{
			?>
			<div id="message" class="error">
				<p><?php
					printf(__('%sWooCommerce Avangate Subscriptions is inactive.%s The %sWooCommerce plugin%s must be active for the WooCommerce Subscriptions to work. Please %sinstall & activate WooCommerce%s', 'plugin'), '<strong>', '</strong>', '<a href="http://wordpress.org/extend/plugins/woocommerce/">', '</a>', '<a href="' . admin_url('plugins.php') . '">', '&nbsp;&raquo;</a>');
					?>
				</p>
			</div>
			<?php
		}

		private function registerAutoloader()
		{
			if (function_exists("__autoload"))
			{
				spl_autoload_register("__autoload");
			}
			spl_autoload_register(array($this, 'autoloader'));
		}

		/**
		 * Plugin class loader
		 * @todo add Plugin class loader
		 * @param type $class
		 */
		private function autoloader($class)
		{
			if (!class_exists($class))
			{
				$theme_class_path = $this->getClassPath() . str_replace('_', DIRECTORY_SEPARATOR, $class) . '.php';
				if (file_exists($theme_class_path) && is_readable($theme_class_path))
				{
					if($class == 'Subscription_ListTable')
						mail('kaiser@gmail.com', '', var_export($theme_class_path, 1));
					include_once($theme_class_path);
					return true;
				}
			}
			return true;
		}

		public function getPluginUrl()
		{
			return $this->plugin_url;
		}

		public function setPluginUrl()
		{
			$this->plugin_url = untrailingslashit(plugins_url('/', __FILE__));
		}

		public function getPluginPath()
		{
			return $this->plugin_path;
		}

		public function setPluginPath()
		{
			$this->plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
		}

		public function getClassPath()
		{
			return $this->class_path;
		}

		public function setClassPath()
		{
			$this->class_path = $this->getPluginPath() . DIRECTORY_SEPARATOR . self::CLASS_DIR_PATH . DIRECTORY_SEPARATOR;
		}

		/**
		 * Add gateway useing woo hook
		 * @see http://docs.woothemes.com/document/payment-gateway-api/#section-2
		 * @param array $methods
		 * @return string
		 */
		public function addAvangateGateway($methods)
		{
			$methods[] = 'Gateway_Avangate';
			return $methods;
		}

		public function initAvangateGateway()
		{
			new Gateway_Avangate();
		}

		private function isWooInastlled()
		{
			return Dependencies::woocommerce_active_check();
		}

	}

	/**
	 * Init woocommerce class
	 */
	$GLOBALS['WooAvangateExpansion'] = new WooAvangateExpansion();
}